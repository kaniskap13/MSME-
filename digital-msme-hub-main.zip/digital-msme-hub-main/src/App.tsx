import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import DashboardPage from "./pages/DashboardPage";
import SalesPage from "./pages/SalesPage";
import InventoryPage from "./pages/InventoryPage";
import ReportsPage from "./pages/ReportsPage";
import AIInsightsPage from "./pages/AIInsightsPage";
import SecurityPage from "./pages/SecurityPage";
import AppLayout from "./components/AppLayout";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function LayoutWrap({ children }: { children: React.ReactNode }) {
  return <AppLayout>{children}</AppLayout>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/dashboard" element={<LayoutWrap><DashboardPage /></LayoutWrap>} />
          <Route path="/sales" element={<LayoutWrap><SalesPage /></LayoutWrap>} />
          <Route path="/inventory" element={<LayoutWrap><InventoryPage /></LayoutWrap>} />
          <Route path="/reports" element={<LayoutWrap><ReportsPage /></LayoutWrap>} />
          <Route path="/ai-insights" element={<LayoutWrap><AIInsightsPage /></LayoutWrap>} />
          <Route path="/security" element={<LayoutWrap><SecurityPage /></LayoutWrap>} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
