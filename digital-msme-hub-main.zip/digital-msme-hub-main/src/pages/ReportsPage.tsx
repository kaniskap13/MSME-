import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const gstData = [
  { month: "Sep 2024", sales: 280000, gst: 15200, status: "Paid" },
  { month: "Oct 2024", sales: 320000, gst: 17400, status: "Paid" },
  { month: "Nov 2024", sales: 290000, gst: 15800, status: "Paid" },
  { month: "Dec 2024", sales: 380000, gst: 20500, status: "Paid" },
  { month: "Jan 2025", sales: 345000, gst: 18400, status: "Pending" },
];

const topProducts = [
  { name: "Rice Bags", sold: 340, revenue: 289000 },
  { name: "Cooking Oil", sold: 210, revenue: 88200 },
  { name: "Sugar", sold: 560, revenue: 30800 },
  { name: "Wheat Flour", sold: 180, revenue: 68400 },
  { name: "Dal", sold: 150, revenue: 24000 },
];

const chartData = gstData.map((d) => ({ month: d.month.split(" ")[0], sales: d.sales / 1000, gst: d.gst / 1000 }));

export default function ReportsPage() {
  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">Sales vs GST (₹ in thousands)</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,20%,88%)" />
                <XAxis dataKey="month" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip formatter={(v: number) => `₹${v}k`} />
                <Bar dataKey="sales" fill="hsl(220,70%,35%)" radius={[3,3,0,0]} name="Sales" />
                <Bar dataKey="gst" fill="hsl(30,90%,55%)" radius={[3,3,0,0]} name="GST" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Top Selling Products</CardTitle></CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Units Sold</TableHead>
                  <TableHead>Revenue</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topProducts.map((p) => (
                  <TableRow key={p.name}>
                    <TableCell className="font-medium">{p.name}</TableCell>
                    <TableCell>{p.sold}</TableCell>
                    <TableCell>₹{p.revenue.toLocaleString("en-IN")}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">GST Report</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month</TableHead>
                <TableHead>Total Sales</TableHead>
                <TableHead>GST Amount</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {gstData.map((d) => (
                <TableRow key={d.month}>
                  <TableCell className="font-medium">{d.month}</TableCell>
                  <TableCell>₹{d.sales.toLocaleString("en-IN")}</TableCell>
                  <TableCell>₹{d.gst.toLocaleString("en-IN")}</TableCell>
                  <TableCell>
                    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                      d.status === "Paid" ? "bg-accent/10 text-accent" : "bg-warning/10 text-warning"
                    }`}>{d.status}</span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
