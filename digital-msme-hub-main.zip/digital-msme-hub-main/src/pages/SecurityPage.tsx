import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Lock, Database, Clock } from "lucide-react";

const loginHistory = [
  { date: "2025-02-10 14:32", ip: "192.168.1.45", device: "Chrome / Windows", status: "Success" },
  { date: "2025-02-10 09:15", ip: "192.168.1.45", device: "Chrome / Windows", status: "Success" },
  { date: "2025-02-09 18:22", ip: "103.24.56.78", device: "Safari / iPhone", status: "Success" },
  { date: "2025-02-09 08:05", ip: "192.168.1.45", device: "Chrome / Windows", status: "Success" },
  { date: "2025-02-08 22:10", ip: "45.67.89.12", device: "Firefox / Linux", status: "Failed" },
];

const securityChecks = [
  { icon: Lock, label: "Password Encryption", status: "Active", desc: "SHA-256 hashing enabled", ok: true },
  { icon: Database, label: "Data Encryption", status: "Active", desc: "AES-256 encryption at rest", ok: true },
  { icon: Shield, label: "SQL Injection Protection", status: "Active", desc: "Parameterized queries enabled", ok: true },
  { icon: Clock, label: "Last Backup", status: "2 hours ago", desc: "Automated daily backups", ok: true },
];

export default function SecurityPage() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {securityChecks.map((c) => (
          <Card key={c.label} className="stat-card-shadow">
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10 text-accent">
                  <c.icon size={20} />
                </div>
                <Badge variant="secondary" className="bg-accent/10 text-accent border-0 text-xs">{c.status}</Badge>
              </div>
              <p className="font-semibold text-sm text-foreground">{c.label}</p>
              <p className="text-xs text-muted-foreground">{c.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Login History</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-muted-foreground">
                <th className="pb-2 pr-4 font-medium">Date & Time</th>
                <th className="pb-2 pr-4 font-medium">IP Address</th>
                <th className="pb-2 pr-4 font-medium">Device</th>
                <th className="pb-2 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {loginHistory.map((h, i) => (
                <tr key={i} className="border-b last:border-0">
                  <td className="py-3 pr-4 text-muted-foreground">{h.date}</td>
                  <td className="py-3 pr-4 font-mono text-xs">{h.ip}</td>
                  <td className="py-3 pr-4">{h.device}</td>
                  <td className="py-3">
                    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                      h.status === "Success" ? "bg-accent/10 text-accent" : "bg-destructive/10 text-destructive"
                    }`}>{h.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">DigiLocker - Document Storage</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {["GST_Report_Jan2025.pdf", "GST_Report_Dec2024.pdf", "GST_Report_Nov2024.pdf"].map((doc) => (
              <div key={doc} className="flex items-center justify-between rounded-lg border p-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded bg-destructive/10 text-destructive text-xs font-bold">
                    PDF
                  </div>
                  <span className="text-sm font-medium">{doc}</span>
                </div>
                <Badge variant="secondary" className="text-xs">Stored in DigiLocker</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
