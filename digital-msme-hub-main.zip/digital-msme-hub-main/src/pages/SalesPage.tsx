import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";

const initialSales = [
  { id: 1, product: "Rice Bags", qty: 10, price: 850, mode: "UPI", date: "2025-02-10" },
  { id: 2, product: "Cooking Oil", qty: 5, price: 420, mode: "Cash", date: "2025-02-10" },
  { id: 3, product: "Sugar", qty: 8, price: 55, mode: "Card", date: "2025-02-09" },
];

export default function SalesPage() {
  const [sales, setSales] = useState(initialSales);
  const [product, setProduct] = useState("");
  const [qty, setQty] = useState("");
  const [price, setPrice] = useState("");
  const [mode, setMode] = useState("");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!product || !qty || !price || !mode) return;
    const newSale = {
      id: Date.now(),
      product,
      qty: Number(qty),
      price: Number(price),
      mode,
      date: new Date().toISOString().slice(0, 10),
    };
    setSales([newSale, ...sales]);
    setProduct(""); setQty(""); setPrice(""); setMode("");
    if (mode === "UPI") {
      toast.success("UPI Payment Successful! Transaction ID: UPI" + Date.now().toString().slice(-8));
    } else {
      toast.success("Sale recorded successfully!");
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">New Sale Entry</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAdd} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <div>
              <Label>Product Name</Label>
              <Input value={product} onChange={(e) => setProduct(e.target.value)} placeholder="Rice Bags" className="mt-1" />
            </div>
            <div>
              <Label>Quantity</Label>
              <Input type="number" value={qty} onChange={(e) => setQty(e.target.value)} placeholder="10" className="mt-1" />
            </div>
            <div>
              <Label>Price (₹)</Label>
              <Input type="number" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="850" className="mt-1" />
            </div>
            <div>
              <Label>Payment Mode</Label>
              <Select value={mode} onValueChange={setMode}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="UPI">UPI</SelectItem>
                  <SelectItem value="Cash">Cash</SelectItem>
                  <SelectItem value="Card">Card</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button type="submit" className="w-full">Add Sale</Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Recent Sales</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Qty</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Payment</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sales.map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="text-muted-foreground">{s.date}</TableCell>
                  <TableCell className="font-medium">{s.product}</TableCell>
                  <TableCell>{s.qty}</TableCell>
                  <TableCell>₹{s.price}</TableCell>
                  <TableCell className="font-semibold">₹{(s.qty * s.price).toLocaleString("en-IN")}</TableCell>
                  <TableCell>
                    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                      s.mode === "UPI" ? "bg-primary/10 text-primary" :
                      s.mode === "Card" ? "bg-info/10 text-info" :
                      "bg-accent/10 text-accent"
                    }`}>
                      {s.mode}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
