import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { IndianRupee, TrendingUp, AlertTriangle, Receipt } from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell,
} from "recharts";

const stats = [
  { label: "Today's Sales", value: "₹24,500", icon: IndianRupee, color: "bg-primary" },
  { label: "Monthly Sales", value: "₹3,45,000", icon: TrendingUp, color: "bg-accent" },
  { label: "Low Stock Items", value: "4", icon: AlertTriangle, color: "bg-warning" },
  { label: "GST Payable", value: "₹18,400", icon: Receipt, color: "bg-secondary" },
];

const monthlySales = [
  { month: "Sep", sales: 280000 },
  { month: "Oct", sales: 320000 },
  { month: "Nov", sales: 290000 },
  { month: "Dec", sales: 380000 },
  { month: "Jan", sales: 345000 },
  { month: "Feb", sales: 370000, predicted: true },
];

const topProducts = [
  { name: "Rice Bags", value: 35 },
  { name: "Cooking Oil", value: 28 },
  { name: "Sugar", value: 20 },
  { name: "Others", value: 17 },
];
const PIE_COLORS = [
  "hsl(220, 70%, 35%)",
  "hsl(30, 90%, 55%)",
  "hsl(150, 50%, 40%)",
  "hsl(200, 80%, 50%)",
];

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="stat-card-shadow">
            <CardContent className="flex items-center gap-4 p-4">
              <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${s.color} text-primary-foreground`}>
                <s.icon size={22} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className="text-xl font-bold text-foreground">{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Monthly Sales Chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Monthly Sales & AI Prediction</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={monthlySales}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(214, 20%, 88%)" />
                <XAxis dataKey="month" fontSize={12} />
                <YAxis fontSize={12} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => `₹${v.toLocaleString("en-IN")}`} />
                <Bar dataKey="sales" fill="hsl(220, 70%, 35%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top Products */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Top Products</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={topProducts} cx="50%" cy="50%" outerRadius={90} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} fontSize={11}>
                  {topProducts.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* GST Trend */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">GST Trend (Last 6 Months)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={[
              { month: "Sep", gst: 15200 },
              { month: "Oct", gst: 17400 },
              { month: "Nov", gst: 15800 },
              { month: "Dec", gst: 20500 },
              { month: "Jan", gst: 18400 },
              { month: "Feb", gst: 19800 },
            ]}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214, 20%, 88%)" />
              <XAxis dataKey="month" fontSize={12} />
              <YAxis fontSize={12} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => `₹${v.toLocaleString("en-IN")}`} />
              <Line type="monotone" dataKey="gst" stroke="hsl(30, 90%, 55%)" strokeWidth={2} dot={{ fill: "hsl(30, 90%, 55%)" }} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
