import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Plus, Pencil, Trash2 } from "lucide-react";

interface Product {
  id: number;
  name: string;
  stock: number;
  price: number;
}

const initialProducts: Product[] = [
  { id: 1, name: "Rice Bags (25kg)", stock: 45, price: 850 },
  { id: 2, name: "Cooking Oil (1L)", stock: 3, price: 420 },
  { id: 3, name: "Sugar (1kg)", stock: 120, price: 55 },
  { id: 4, name: "Wheat Flour (10kg)", stock: 8, price: 380 },
  { id: 5, name: "Dal (1kg)", stock: 2, price: 160 },
];

const LOW_STOCK = 10;

export default function InventoryPage() {
  const [products, setProducts] = useState(initialProducts);
  const [name, setName] = useState("");
  const [stock, setStock] = useState("");
  const [price, setPrice] = useState("");
  const [editId, setEditId] = useState<number | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !stock || !price) return;

    if (editId !== null) {
      setProducts(products.map((p) => p.id === editId ? { ...p, name, stock: Number(stock), price: Number(price) } : p));
      setEditId(null);
      toast.success("Product updated");
    } else {
      setProducts([...products, { id: Date.now(), name, stock: Number(stock), price: Number(price) }]);
      toast.success("Product added");
    }
    setName(""); setStock(""); setPrice("");
  };

  const handleEdit = (p: Product) => {
    setEditId(p.id); setName(p.name); setStock(String(p.stock)); setPrice(String(p.price));
  };

  const handleDelete = (id: number) => {
    setProducts(products.filter((p) => p.id !== id));
    toast.success("Product deleted");
  };

  const lowStockCount = products.filter((p) => p.stock <= LOW_STOCK).length;

  return (
    <div className="space-y-6">
      {lowStockCount > 0 && (
        <Card className="border-warning/50 bg-warning/5">
          <CardContent className="flex items-center gap-3 p-4">
            <span className="text-warning text-lg">⚠️</span>
            <p className="text-sm font-medium text-foreground">
              {lowStockCount} product{lowStockCount > 1 ? "s" : ""} running low on stock!
            </p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Plus size={18} /> {editId ? "Edit Product" : "Add Product"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid gap-4 sm:grid-cols-4">
            <div>
              <Label>Product Name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Product name" className="mt-1" />
            </div>
            <div>
              <Label>Stock Quantity</Label>
              <Input type="number" value={stock} onChange={(e) => setStock(e.target.value)} placeholder="50" className="mt-1" />
            </div>
            <div>
              <Label>Price (₹)</Label>
              <Input type="number" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="850" className="mt-1" />
            </div>
            <div className="flex items-end gap-2">
              <Button type="submit" className="flex-1">{editId ? "Update" : "Add"}</Button>
              {editId && <Button type="button" variant="outline" onClick={() => { setEditId(null); setName(""); setStock(""); setPrice(""); }}>Cancel</Button>}
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Product Inventory</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead>Stock</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.name}</TableCell>
                  <TableCell>{p.stock}</TableCell>
                  <TableCell>₹{p.price}</TableCell>
                  <TableCell>
                    {p.stock <= LOW_STOCK ? (
                      <Badge variant="destructive" className="text-xs">Low Stock</Badge>
                    ) : (
                      <Badge variant="secondary" className="bg-accent/10 text-accent border-0 text-xs">In Stock</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(p)}><Pencil size={15} /></Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(p.id)}><Trash2 size={15} /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
