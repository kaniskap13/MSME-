import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { Brain, TrendingUp, Package } from "lucide-react";

const predictionData = [
  { month: "Oct", actual: 320000 },
  { month: "Nov", actual: 290000 },
  { month: "Dec", actual: 380000 },
  { month: "Jan", actual: 345000 },
  { month: "Feb", predicted: 370000 },
  { month: "Mar", predicted: 395000 },
];

const demandTrend = [
  { product: "Rice Bags", current: 45, suggested: 70 },
  { product: "Cooking Oil", current: 3, suggested: 30 },
  { product: "Sugar", current: 120, suggested: 100 },
  { product: "Wheat Flour", current: 8, suggested: 25 },
  { product: "Dal", current: 2, suggested: 20 },
];

const insights = [
  { icon: TrendingUp, title: "Next Month Prediction", value: "₹3,95,000", desc: "Based on 3-month average trend" },
  { icon: Brain, title: "Growth Rate", value: "+7.2%", desc: "Month-over-month increase" },
  { icon: Package, title: "Restock Needed", value: "3 Items", desc: "Cooking Oil, Wheat Flour, Dal" },
];

export default function AIInsightsPage() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        {insights.map((ins) => (
          <Card key={ins.title} className="stat-card-shadow">
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <ins.icon size={22} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{ins.title}</p>
                <p className="text-xl font-bold text-foreground">{ins.value}</p>
                <p className="text-xs text-muted-foreground">{ins.desc}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Sales Prediction (AI Model)</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={predictionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,20%,88%)" />
              <XAxis dataKey="month" fontSize={12} />
              <YAxis fontSize={12} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => `₹${v.toLocaleString("en-IN")}`} />
              <Line type="monotone" dataKey="actual" stroke="hsl(220,70%,35%)" strokeWidth={2} dot={{ fill: "hsl(220,70%,35%)" }} name="Actual" />
              <Line type="monotone" dataKey="predicted" stroke="hsl(30,90%,55%)" strokeWidth={2} strokeDasharray="5 5" dot={{ fill: "hsl(30,90%,55%)" }} name="Predicted" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Suggested Stock Quantities</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={demandTrend} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,20%,88%)" />
              <XAxis type="number" fontSize={12} />
              <YAxis type="category" dataKey="product" fontSize={12} width={100} />
              <Tooltip />
              <Bar dataKey="current" fill="hsl(220,70%,35%)" name="Current Stock" radius={[0,3,3,0]} />
              <Bar dataKey="suggested" fill="hsl(150,50%,40%)" name="Suggested Stock" radius={[0,3,3,0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
