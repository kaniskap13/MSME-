import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function LoginPage() {
  const navigate = useNavigate();
  const [isSignup, setIsSignup] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/dashboard");
  };

  return (
    <div className="flex min-h-screen">
      {/* Left Panel */}
      <div className="hidden lg:flex lg:w-1/2 gradient-hero items-center justify-center p-12">
        <div className="max-w-md text-center">
          <div className="mb-8 flex justify-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-secondary text-secondary-foreground font-bold text-3xl">
              M
            </div>
          </div>
          <h1 className="text-3xl font-bold text-primary-foreground mb-4">
            INDIA MSME Digital Stack
          </h1>
          <p className="text-primary-foreground/80 text-lg leading-relaxed">
            Empowering Micro, Small &amp; Medium Enterprises with digital tools for accounting, GST compliance, and AI-powered business insights.
          </p>
          <div className="mt-10 grid grid-cols-3 gap-4 text-primary-foreground/70 text-xs">
            <div className="rounded-lg bg-primary-foreground/10 p-3">
              <p className="font-semibold text-primary-foreground text-lg">10L+</p>
              <p>MSMEs Onboarded</p>
            </div>
            <div className="rounded-lg bg-primary-foreground/10 p-3">
              <p className="font-semibold text-primary-foreground text-lg">₹500Cr</p>
              <p>Sales Tracked</p>
            </div>
            <div className="rounded-lg bg-primary-foreground/10 p-3">
              <p className="font-semibold text-primary-foreground text-lg">99.9%</p>
              <p>Uptime</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <div className="flex w-full lg:w-1/2 items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="lg:hidden mb-8 text-center">
            <div className="inline-flex h-14 w-14 items-center justify-center rounded-xl bg-primary text-primary-foreground font-bold text-xl mb-3">
              M
            </div>
            <h1 className="text-xl font-bold text-foreground">INDIA MSME Digital Stack</h1>
          </div>

          <h2 className="text-2xl font-bold text-foreground mb-1">
            {isSignup ? "Create Account" : "Welcome Back"}
          </h2>
          <p className="text-muted-foreground mb-6">
            {isSignup ? "Register your MSME business" : "Sign in to your MSME dashboard"}
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignup && (
              <div>
                <Label htmlFor="businessName">Business Name</Label>
                <Input id="businessName" placeholder="ABC Traders" className="mt-1" />
              </div>
            )}
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="owner@abctraders.com" className="mt-1" />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" placeholder="••••••••" className="mt-1" />
            </div>
            {isSignup && (
              <div>
                <Label htmlFor="gst">GST Number (Optional)</Label>
                <Input id="gst" placeholder="27AABCU9603R1ZM" className="mt-1" />
              </div>
            )}
            <Button type="submit" className="w-full">
              {isSignup ? "Create Account" : "Sign In"}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {isSignup ? "Already have an account?" : "Don't have an account?"}{" "}
            <button
              onClick={() => setIsSignup(!isSignup)}
              className="font-medium text-primary hover:underline"
            >
              {isSignup ? "Sign In" : "Sign Up"}
            </button>
          </p>

          <p className="mt-8 text-center text-xs text-muted-foreground">
            A Digital India Initiative • Powered by MSME Ministry
          </p>
        </div>
      </div>
    </div>
  );
}
